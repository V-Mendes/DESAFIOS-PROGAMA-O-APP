package com.example.d2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.d2.databinding.ActivityMainBinding
import kotlin.math.ceil

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding
    private fun calcular(){
      val cost = binding.TotalAPagar.text.toString().toDouble()
        val selectedid = binding.opEs.checkedRadioButtonId
        val porcentagem = when(selectedid){
            R.id.opção_dez_porcento -> 0.1
            R.id.opção_sete_porcento -> 0.07
            else -> 0.05
        }
       var pagar = cost*porcentagem
        val roundup = binding.arredondar.isChecked
        if(roundup){
            pagar = ceil(pagar)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.botOCalcular.setOnClickListener { calcular() }


    }
}