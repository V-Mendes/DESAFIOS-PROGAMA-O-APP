package com.example.formulario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MostrarDados extends AppCompatActivity {
    TextView tvNome, tvSobrenome, tvIdade, tvEndereço;
    Button btnOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_dados);

        tvNome = (TextView) findViewById(R.id.tvNome);
        tvSobrenome = (TextView) findViewById(R.id.tvSobrenome);
        tvIdade = (TextView) findViewById(R.id.tvIdade);
        tvEndereço = (TextView) findViewById(R.id.tvEndereço);
        btnOK = (Button)findViewById(R.id.btnOK);

        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MostrarDados.this,MainActivity.class);
                startActivity(intent);
            }
        });

        mostrarDados();
    }
    private void mostrarDados(){
        Bundle dados = this.getIntent() .getExtras();
        String nome = dados.getString("name");
        String idade = dados.getString("ida");
        String Sobrenome = dados.getString("ape");
        String endereço = dados.getString("end");

        tvNome.setText(nome);
        tvSobrenome.setText(Sobrenome);
        tvIdade.setText(idade);
        tvEndereço.setText(endereço);


    }
}