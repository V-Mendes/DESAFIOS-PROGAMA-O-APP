package com.example.formulario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText nome, sobrenome, idade, endereço;
    Button confirmar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = (EditText) findViewById(R.id.editNome);
        sobrenome = (EditText) findViewById(R.id.editSobrenome);
        idade = (EditText) findViewById(R.id.editIdade);
        endereço = (EditText) findViewById(R.id.editEndereço);
        confirmar = (Button) findViewById(R.id.btnconfirmar);

        confirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String name = nome.getText() .toString();
            String ape = sobrenome.getText() .toString();
            String ida = idade.getText() .toString();
            String end= endereço.getText() .toString();

            Intent i = new Intent(MainActivity.this, MostrarDados.class);

            i.putExtra("name",name);
            i.putExtra("ida",ida);
            i.putExtra("ape",ape);
            i.putExtra("end",end);

            startActivity(i);

            }
        });


    }
}