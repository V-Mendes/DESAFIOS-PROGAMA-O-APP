package com.example.aula12

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var longitude = "-48.028871041204184"
        var latitude = "15.86395916559091"

        val button: Button = findViewById(R.id.button)

        button.setOnClickListener {
            var url = Uri! Uri.parse("geo:${editText.text.toString()}?q=$latitude,$longitude")

            val intent = Intent(Intent.ACTION_VIEW, url)
            startActivity(intent)
        }
    }
}