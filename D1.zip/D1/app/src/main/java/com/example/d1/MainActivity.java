package com.example.d1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private Button bt_ok;

    private TextView txt;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_ok = findViewById(R.id.bt_ok);
        txt = findViewById(R.id.txt_gire);
        imageView = findViewById(R.id.imageView);

        bt_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               //codigo pra clicar no botão

                Timer timer = new Timer();
                int dado1 = R.drawable.dice_1;
                int dado2 = R.drawable.dice_2;
                int dado3 = R.drawable.dice_3;
                int dado4 = R.drawable.dice_4;
                int dado5 = R.drawable.dice_5;
                int dado6 = R.drawable.dice_6;
                List<Integer> imagens = new ArrayList<>();
                imagens.add(dado1);
                imagens.add(dado2);
                imagens.add(dado3);
                imagens.add(dado4);
                imagens.add(dado5);
                imagens.add(dado6);

                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        Random r = new Random();

                        imageView.setImageResource(imagens.get(r.nextInt(5)));



                    }
                },500,500);


            }
        });
    }
}