package com.example.d9;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView autoCompleteTextView;
    private Button btnRestaurante, btnPais, btnShopping, buttonPesquisar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
        btnRestaurante = findViewById(R.id.btnRestaurante);
        btnPais = findViewById(R.id.btnPais);
        btnShopping = findViewById(R.id.btnShopping);
        buttonPesquisar = findViewById(R.id.buttonPesquisar);

        String[] suggestions = {"Restaurante Favorito", "Brasil", "Shopping Brasília - DF"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, suggestions);
        autoCompleteTextView.setAdapter(adapter);

        btnRestaurante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                
                abrirMapa(37.7749, -122.4194);
            }
        });

        btnPais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                abrirMapa(-14.2350, -51.9253);
            }
        });

        btnShopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                abrirMapa(-15.7942, -47.8822);
            }
        });

        buttonPesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "geo:?q=";

                if (autoCompleteTextView.getText().length() > 0) {
                    url = "geo:" + autoCompleteTextView.getText().toString() + "?q=" + autoCompleteTextView.getText().toString();
                    Uri uri = Uri.parse(url);

                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }
            }
        });
    }

    private void abrirMapa(double latitude, double longitude) {

        String uri = "geo:" + latitude + "," + longitude + "?q=" + latitude + "," + longitude;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        startActivity(intent);
    }
}
