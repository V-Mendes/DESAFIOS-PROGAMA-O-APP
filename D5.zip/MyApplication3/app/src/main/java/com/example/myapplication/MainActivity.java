package com.example.myapplication;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

    private EditText editEvent;
    private EditText editDate;
    private EditText editAddress;
    private EditText editQuantity;
    private Button btnSave;
    private SharedPreferences sharedPreferences;
    private TextView textSavedEvent;
    private TextView textSavedDate;
    private TextView textSavedAddress;
    private TextView textSavedQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editEvent = findViewById(R.id.editEvent);
        editDate = findViewById(R.id.editDate);
        editAddress = findViewById(R.id.editAddress);
        editQuantity = findViewById(R.id.editQuantity);
        btnSave = findViewById(R.id.btnSave);


        sharedPreferences = getSharedPreferences("MyEvent", MODE_PRIVATE);


        String savedEvent = sharedPreferences.getString("event", "");
        String savedDate = sharedPreferences.getString("date", "");
        String savedAddress = sharedPreferences.getString("address", "");
        String savedQuantity = sharedPreferences.getString("quantity", "");


        editEvent.setText(savedEvent);
        editDate.setText(savedDate);
        editAddress.setText(savedAddress);
        editQuantity.setText(savedQuantity);

        textSavedEvent = findViewById(R.id.textSavedEvent);
        textSavedDate = findViewById(R.id.textSavedDate);
        textSavedAddress = findViewById(R.id.textSavedAddress);
        textSavedQuantity = findViewById(R.id.textSavedQuantity);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String newEvent = editEvent.getText().toString();
                String newDate = editDate.getText().toString();
                String newAddress = editAddress.getText().toString();
                String newQuantity = editQuantity.getText().toString();


                editEvent.setText(newEvent);
                editDate.setText(newDate);
                editAddress.setText(newAddress);
                editQuantity.setText(newQuantity);


                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("event", newEvent);
                editor.putString("date", newDate);
                editor.putString("address", newAddress);
                editor.putString("quantity", newQuantity);
                editor.apply();

                // Atualize os TextViews para mostrar os dados salvos
                textSavedEvent.setText("Nome do Evento: " + newEvent);
                textSavedDate.setText("Data do Evento: " + newDate);
                textSavedAddress.setText("Endereço do Evento: " + newAddress);
                textSavedQuantity.setText("Quantidade de Pessoas: " + newQuantity);
            }
        });
    }
}
